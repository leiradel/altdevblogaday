/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

public abstract class BinaryOp extends Node
{
  private Node left;
  private Node right;
  
  public BinaryOp()
  {
    super();
    
    left  = null;
    right = null;
  }
  
  public void setLeft( Node left )
  {
    this.left = left;
  }
  
  public Node getLeft()
  {
    return left;
  }
  
  public void setRight( Node right )
  {
    this.right = right;
  }
  
  public Node getRight()
  {
    return right;
  }
  
  public Type getType()
  {
    if ( left.getType() == Type.FLOAT32 )
    {
      return Type.FLOAT32;
    }
    return right.getType();
  }
  
  public String toDot()
  {
    String label = getClass().getName();
    
    int pos = label.lastIndexOf( '.' );
    
    if ( pos != -1 )
    {
      label = label.substring( pos + 1 );
    }
    
    if ( label.endsWith( "Expr" ) )
    {
      label = label.substring( 0, label.length() - 4 );
    }
    
    StringBuilder sb = new StringBuilder();
    
    sb.append( getUid() ).append( " [ shape = record, label = \"{" ).append( label ).append( '|' );
    sb.append( "type: " ).append( getType() );
    sb.append( "}\" ];\n" );
    
    if ( left != null )
    {
      sb.append( left.toDot() );
      sb.append( getUid() ).append( " -> " ).append( left.getUid() ).append( ";\n" );
    }
    
    sb.append( right.toDot() );
    sb.append( getUid() ).append( " -> " ).append( right.getUid() ).append( ";\n" );
    
    return sb.toString();
  }
}  

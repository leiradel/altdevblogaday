/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

public class ForStmt extends Node
{
  private Node init;
  private Node condition;
  private Node update;
  private Node body;
  
  public ForStmt()
  {
    super();
    
    init      = null;
    condition = null;
    update    = null;
    body      = null;
  }
  
  public Node getInit()
  {
    return init;
  }
  
  public void setInit( Node init )
  {
    this.init = init;
  }
  
  public Node getCondition()
  {
    return condition;
  }
  
  public void setCondition( Node condition )
  {
    this.condition = condition;
  }
  
  public Node getUpdate()
  {
    return update;
  }
  
  public void setUpdate( Node update )
  {
    this.update = update;
  }
  
  public Node getBody()
  {
    return body;
  }
  
  public void setBody( Node body )
  {
    this.body = body;
  }
  
  public Type getType()
  {
    return null;
  }
  
  public String toDot()
  {
    StringBuilder sb = new StringBuilder();
    
    sb.append( getUid() ).append( " [ label = \"For\", shape = box ];\n" );
    
    if ( init != null )
    {
      sb.append( init.toDot() );
      sb.append( getUid() ).append( " -> " ).append( init.getUid() ).append( ";\n" );
    }
    
    if ( condition != null )
    {
      sb.append( condition.toDot() );
      sb.append( getUid() ).append( " -> " ).append( condition.getUid() ).append( ";\n" );
    }
    
    if ( update != null )
    {
      sb.append( update.toDot() );
      sb.append( getUid() ).append( " -> " ).append( update.getUid() ).append( ";\n" );
    }
    
    sb.append( body.toDot() );
    sb.append( getUid() ).append( " -> " ).append( body.getUid() ).append( ";\n" );
    
    return sb.toString();
  }
}

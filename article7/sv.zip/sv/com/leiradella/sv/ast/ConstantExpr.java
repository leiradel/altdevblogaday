/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

import java.math.BigInteger;

import edu.rit.numeric.BigRational;

public class ConstantExpr extends Node
{
  private BigRational value;
  private Type        type;
  
  public ConstantExpr()
  {
    super();
    
    value = null;
    type  = null;
  }
  
  public void setType( Type type )
  {
    this.type = type;
  }
  
  public Type getType()
  {
    return type; //value.denominator().compareTo( BigInteger.ONE ) == 0 ? Type.INT32 : Type.FLOAT32;
  }
  
  public void setValue( long value )
  {
    this.value = new BigRational( value );
  }
  
  public void setValue( String value )
  {
    int length  = value.length();
    
    if ( value.charAt( length - 1 ) == 'f' )
    {
      length--;
      value = value.substring( 0, length );
    }
    
    int dot = value.indexOf( '.' );
    int exp = value.indexOf( 'e' );
    
    if ( exp == -1 )
    {
      exp = value.indexOf( 'E' );
    }
    
    int intBegin  = 0;
    int intEnd    = dot != -1 ? dot : ( exp != -1 ? exp : length );
    int fracBegin = dot != -1 ? dot + 1 : -1;
    int fracEnd   = exp != -1 ? exp : length;
    int expBegin  = exp != -1 ? ( value.charAt( exp + 1 ) != '+' ? exp + 1 : exp + 2 ) : -1;
    int expEnd    = length;
    
    BigRational intValue  = intBegin  != -1 && intBegin != intEnd   ? new BigRational( value.substring( intBegin, intEnd ) )   : new BigRational( 0 );
    BigRational fracValue = fracBegin != -1 && fracBegin != fracEnd ? new BigRational( value.substring( fracBegin, fracEnd ) ) : new BigRational( 0 );
    BigRational expValue  = expBegin  != -1 && expBegin != expEnd   ? new BigRational( value.substring( expBegin, expEnd ) )   : new BigRational( 0 );
    
    BigRational zero = new BigRational( 0 );
    BigRational one  = new BigRational( 1 );
    BigRational ten  = new BigRational( 10 );
    
    for ( int i = fracBegin; i < fracEnd; i++ )
    {
      fracValue.div( ten );
    }
    
    BigRational constValue = intValue.add( fracValue );
    
    while ( expValue.compareTo( zero ) > 0 )
    {
      constValue.mul( ten );
      expValue.sub( one );
    }
    
    while ( expValue.compareTo( zero ) < 0 )
    {
      constValue.div( ten );
      expValue.add( one );
    }
    
    this.value = constValue.normalize();
  }
  
  public BigRational getValue()
  {
    return new BigRational( value );
  }
  
  public String toDot()
  {
    StringBuilder sb = new StringBuilder();
    
    sb.append( getUid() ).append( " [ shape = record, label = \"{Constant|" );
    
    sb.append( "value: " ).append( value );
    sb.append( '|' ).append( "type: " ).append( getType() );
    sb.append( "}\" ];\n" );
    
    return sb.toString();
  }
}

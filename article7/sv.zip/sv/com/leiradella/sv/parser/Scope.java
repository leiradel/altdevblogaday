/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.parser;

import java.util.HashMap;
import java.util.Map;

import com.leiradella.sv.ast.ArgDecl;
import com.leiradella.sv.ast.Function;
import com.leiradella.sv.ast.Node;
import com.leiradella.sv.ast.VarDecl;

public class Scope
{
  private Map< String, Node > vars;
  
  public Scope()
  {
    vars = new HashMap< String, Node >();
  }
  
  public void addVar( String name, Node node )
  {
    vars.put( name, node );
  }
  
  public Node getVar( String name )
  {
    return vars.get( name );
  }
  
  public boolean isDeclared( String name )
  {
    return vars.get( name ) != null;
  }
  
  public String[] getVars()
  {
    return vars.keySet().toArray( new String[ vars.size() ] );
  }
}

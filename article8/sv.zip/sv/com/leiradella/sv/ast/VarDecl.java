/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

public class VarDecl extends ArgDecl
{
  private Node value;
  
  public VarDecl()
  {
    super();
    
    value = null;
  }
  
  public Node getValue()
  {
    return value;
  }
  
  public void setValue( Node value )
  {
    this.value = value;
  }
  
  public Node optimize()
  {
    // Optimize variable value.
    if ( value != null )
    {
      value = value.optimize();
    }
    return this;
  }
  
  public String toDot()
  {
    StringBuilder sb = new StringBuilder();
    
    sb.append( getUid() ).append( " [ shape = record, label = \"{VarDecl|" );
    
    sb.append( "name: " ).append( getName() );
    sb.append( '|' ).append( "type: " ).append( getType() );
    sb.append( "}\" ];\n" );
    
    if ( value != null )
    {
      sb.append( value.toDot() );
      sb.append( getUid() ).append( " -> " ).append( value.getUid() ).append( ";\n" );
    }
    
    return sb.toString();
  }
}

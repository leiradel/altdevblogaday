/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

public class IfStmt extends Node
{
  private Node condition;
  private Node whenTrue;
  private Node whenFalse;
  
  public IfStmt()
  {
    super();
    
    condition = null;
    whenTrue  = null;
    whenFalse = null;
  }
  
  public Node getCondition()
  {
    return condition;
  }
  
  public void setCondition( Node condition )
  {
    this.condition = condition;
  }
  
  public Node getWhenTrue()
  {
    return whenTrue;
  }
  
  public void setWhenTrue( Node whenTrue )
  {
    this.whenTrue = whenTrue;
  }
  
  public Node getWhenFalse()
  {
    return whenFalse;
  }
  
  public void setWhenFalse( Node whenFalse )
  {
    this.whenFalse = whenFalse;
  }
  
  public Type getType()
  {
    return null;
  }
  
  public Node optimize()
  {
    // Optimize the condition and the bodies. Note: the "else" body can be null!
    condition = condition.optimize();
    whenTrue  = whenTrue.optimize();
    
    if ( whenFalse != null )
    {
      whenFalse = whenFalse.optimize();
    }
    
    // Dead-code elimination.
    // If the condition is constant, change the if statement to its "then" or "else"
    // body depending on the condition being true or false, respectively.
    if ( condition instanceof ConstantExpr )
    {
      ConstantExpr constant = (ConstantExpr)condition;
      
      if ( constant.isZero() )
      {
        if ( whenFalse != null )
        {
          return whenFalse;
        }
        constant = new ConstantExpr();
        constant.setValue( 0 );
        return constant;
      }
      else
      {
        return whenTrue;
      }
    }
    return this;
  }
  
  public String toDot()
  {
    StringBuilder sb = new StringBuilder();
    
    sb.append( getUid() ).append( " [ label = \"If\", shape = box ];\n" );
    
    sb.append( condition.toDot() );
    sb.append( getUid() ).append( " -> " ).append( condition.getUid() ).append( ";\n" );
    
    sb.append( whenTrue.toDot() );
    sb.append( getUid() ).append( " -> " ).append( whenTrue.getUid() ).append( ";\n" );
    
    sb.append( whenFalse.toDot() );
    sb.append( getUid() ).append( " -> " ).append( whenFalse.getUid() ).append( ";\n" );
    
    return sb.toString();
  }
}

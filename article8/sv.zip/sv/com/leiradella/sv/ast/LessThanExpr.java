/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

public class LessThanExpr extends BinaryOp
{
  public Type getType()
  {
    return Type.INT32;
  }
  
  public Node optimize()
  {
    // Optimize operands.
    Node left  = getLeft().optimize();
    Node right = getRight().optimize();
    
    setLeft( left );
    setRight( right );
    
    // Constant folding optimization.
    if ( ( left instanceof ConstantExpr ) && ( right instanceof ConstantExpr ) )
    {
      ConstantExpr leftOp  = (ConstantExpr)left;
      ConstantExpr rightOp = (ConstantExpr)right;
      
      leftOp.setValue( leftOp.compareTo( rightOp ) < 0 ? 1 : 0 );
      leftOp.setType( Type.INT32 );
      return leftOp;
    }
    
    return this;
  }
}

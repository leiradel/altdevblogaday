/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import edu.rit.numeric.BigRational;

public class ConstantExpr extends Node
{
  private static final BigRational ZERO      = new BigRational( 0 );
  private static final BigRational ONE       = new BigRational( 1 );
  private static final BigRational MINUS_ONE = new BigRational( -1 );
  
  private BigRational value;
  private Type        type;
  
  public ConstantExpr()
  {
    super();
    
    value = null;
    type  = null;
  }
  
  public void setType( Type type )
  {
    this.type = type;
  }
  
  public Type getType()
  {
    return type; //value.denominator().compareTo( BigInteger.ONE ) == 0 ? Type.INT32 : Type.FLOAT32;
  }
  
  public void setValue( long value )
  {
    this.value = new BigRational( value );
  }
  
  public void setValue( String value )
  {
    int length  = value.length();
    
    if ( value.charAt( length - 1 ) == 'f' )
    {
      length--;
      value = value.substring( 0, length );
    }
    
    int dot = value.indexOf( '.' );
    int exp = value.indexOf( 'e' );
    
    if ( exp == -1 )
    {
      exp = value.indexOf( 'E' );
    }
    
    int intBegin  = 0;
    int intEnd    = dot != -1 ? dot : ( exp != -1 ? exp : length );
    int fracBegin = dot != -1 ? dot + 1 : -1;
    int fracEnd   = exp != -1 ? exp : length;
    int expBegin  = exp != -1 ? ( value.charAt( exp + 1 ) != '+' ? exp + 1 : exp + 2 ) : -1;
    int expEnd    = length;
    
    BigRational intValue  = intBegin  != -1 && intBegin != intEnd   ? new BigRational( value.substring( intBegin, intEnd ) )   : new BigRational( 0 );
    BigRational fracValue = fracBegin != -1 && fracBegin != fracEnd ? new BigRational( value.substring( fracBegin, fracEnd ) ) : new BigRational( 0 );
    BigRational expValue  = expBegin  != -1 && expBegin != expEnd   ? new BigRational( value.substring( expBegin, expEnd ) )   : new BigRational( 0 );
    
    BigRational ten = new BigRational( 10 );
    
    for ( int i = fracBegin; i < fracEnd; i++ )
    {
      fracValue.div( ten );
    }
    
    BigRational constValue = intValue.add( fracValue );
    
    while ( expValue.compareTo( ZERO ) > 0 )
    {
      constValue.mul( ten );
      expValue.sub( ONE );
    }
    
    while ( expValue.compareTo( ZERO ) < 0 )
    {
      constValue.div( ten );
      expValue.add( ONE );
    }
    
    this.value = constValue.normalize();
  }
  
  public void setValue( BigRational value )
  {
    this.value = new BigRational( value ).normalize();
  }
  
  public BigRational getValue()
  {
    return new BigRational( value );
  }
  
  public String toDot()
  {
    StringBuilder sb = new StringBuilder();
    
    sb.append( getUid() ).append( " [ shape = record, label = \"{Constant|" );
    
    sb.append( "value: " ).append( value );
    sb.append( '|' ).append( "type: " ).append( getType() );
    sb.append( "}\" ];\n" );
    
    return sb.toString();
  }
  
  public int compareTo( ConstantExpr other )
  {
    return value.compareTo( other.value );
  }
  
  public boolean isZero()
  {
    return value.compareTo( ZERO ) == 0;
  }
  
  public boolean isOne()
  {
    return value.compareTo( ONE ) == 0;
  }
  
  public boolean isMinusOne()
  {
    return value.compareTo( MINUS_ONE ) == 0;
  }
  
  public boolean isInteger()
  {
    return value.denominator().compareTo( BigInteger.ONE ) == 0;
  }
  
  public void roundDown()
  {
    BigDecimal numer = new BigDecimal( value.numerator() );
    BigDecimal denom = new BigDecimal( value.denominator() );
    BigDecimal trunc = numer.divide( denom, 1, RoundingMode.DOWN );
    value = new BigRational( trunc.toBigInteger() );
  }
  
  public void add( ConstantExpr other )
  {
    value.add( other.value ).normalize();
  }
  
  public void sub( ConstantExpr other )
  {
    value.sub( other.value ).normalize();
  }
  
  public void mul( ConstantExpr other )
  {
    value.mul( other.value ).normalize();
  }
  
  public void div( ConstantExpr other )
  {
    value.div( other.value ).normalize();
  }
  
  public void rem( ConstantExpr other )
  {
    value.rem( other.value ).normalize();
  }
  
  public void negate()
  {
    value.negate();
  }
  
  public void recip()
  {
    value.recip().normalize();
  }
  
  public void intdiv( ConstantExpr other )
  {
    assert( isInteger() && other.isInteger() );
    value = new BigRational( value.numerator().divide( other.value.numerator() ) );
  }
  
  public void intrem( ConstantExpr other )
  {
    assert( isInteger() && other.isInteger() );
    value = new BigRational( value.numerator().mod( other.value.numerator() ) );
  }
  
  public void and( ConstantExpr other )
  {
    assert( isInteger() && other.isInteger() );
    value = new BigRational( value.numerator().and( other.value.numerator() ) );
  }
  
  public void or( ConstantExpr other )
  {
    assert( isInteger() && other.isInteger() );
    value = new BigRational( value.numerator().or( other.value.numerator() ) );
  }
  
  public void xor( ConstantExpr other )
  {
    assert( isInteger() && other.isInteger() );
    value = new BigRational( value.numerator().xor( other.value.numerator() ) );
  }
  
  public void invert()
  {
    assert( isInteger() );
    value = new BigRational( value.numerator().not() );
  }
  
  public void shl( ConstantExpr other )
  {
    assert( isInteger() && other.isInteger() );
    
    BigInteger res   = BigInteger.ZERO.add( value.numerator() );
    BigInteger count = BigInteger.ZERO.add( other.value.numerator() );
    BigInteger power = BigInteger.valueOf( 1 << 30 );
    
    while ( count.compareTo( BigInteger.ZERO ) >= 0 )
    {
      while ( count.compareTo( power ) > 0 )
      {
        res = res.shiftLeft( power.intValue() );
        count = count.subtract( power );
      }
      power = power.shiftRight( 1 );
    }
    
    value = new BigRational( res );
  }
  
  public void shr( ConstantExpr other )
  {
    assert( isInteger() && other.isInteger() );
    
    BigInteger res   = BigInteger.ZERO.add( value.numerator() );
    BigInteger count = BigInteger.ZERO.add( other.value.numerator() );
    BigInteger power = BigInteger.valueOf( 1 << 30 );
    
    while ( count.compareTo( BigInteger.ZERO ) >= 0 )
    {
      while ( count.compareTo( power ) > 0 )
      {
        res = res.shiftRight( power.intValue() );
        count = count.subtract( power );
      }
      power = power.shiftRight( 1 );
    }
    
    value = new BigRational( res );
  }
}

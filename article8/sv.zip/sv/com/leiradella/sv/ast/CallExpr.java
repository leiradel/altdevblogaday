/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

import java.util.ArrayList;
import java.util.List;

public class CallExpr extends Node
{
  private Function     function;
  private List< Node > args;
  
  public CallExpr()
  {
    super();
    
    function = null;
    args     = new ArrayList< Node >();
  }
  
  public void setFunction( Function function )
  {
    this.function = function;
  }
  
  public Function getFunction()
  {
    return function;
  }
  
  public void addArg( Node node )
  {
    args.add( node );
  }
  
  public int getNumArgs()
  {
    return args.size();
  }
  
  public Node getArg( int index )
  {
    return args.get( index );
  }
  
  public Type getType()
  {
    return function.getType();
  }
  
  public Node optimize()
  {
    // Optimize function arguments.
    for ( int i = 0; i < args.size(); i++ )
    {
      args.set( i, args.get( i ).optimize() );
    }
    return this;
  }
  
  public String toDot()
  {
    StringBuilder sb = new StringBuilder();
    
    sb.append( getUid() ).append( " [ shape = record, label = \"{Call|" );
    sb.append( "function: " ).append( function.getName() ).append( '|' );
    sb.append( "type: " ).append( getType() );
    sb.append( "}\" ];\n" );
    
    for ( Node n: args )
    {
      sb.append( n.toDot() );
      sb.append( getUid() ).append( " -> " ).append( n.getUid() ).append( ";\n" );
    }
    
    return sb.toString();
  }
}

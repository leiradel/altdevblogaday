/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

public class BitwiseXorExpr extends BinaryOp
{
  public Type getType()
  {
    return Type.INT32;
  }
  
  public Node optimize()
  {
    // Optimize operands.
    Node left  = getLeft().optimize();
    Node right = getRight().optimize();
    
    setLeft( left );
    setRight( right );
    
    // Constant folding optimization.
    if ( ( left instanceof ConstantExpr ) && ( right instanceof ConstantExpr ) )
    {
      ConstantExpr leftOp  = (ConstantExpr)left;
      ConstantExpr rightOp = (ConstantExpr)right;
      
      leftOp.xor( rightOp );
      leftOp.setType( Type.INT32 );
      return leftOp;
    }

    // Constant propagation.
    if ( left instanceof ConstantExpr )
    {
      ConstantExpr leftOp = (ConstantExpr)left;
      
      // 0 ^ x == x
      if ( leftOp.isZero() )
      {
        return right;
      }
      
      // -1 ^ x == ~x
      if ( leftOp.isMinusOne() )
      {
        InvertExpr inv = new InvertExpr();
        inv.setValue( right );
        return inv;
      }
    }
    
    if ( right instanceof ConstantExpr )
    {
      ConstantExpr rightOp = (ConstantExpr)right;
      
      // x ^ 0 == x
      if ( rightOp.isZero() )
      {
        return left;
      }
      
      // x ^ -1 == ~x
      if ( rightOp.isMinusOne() )
      {
        InvertExpr inv = new InvertExpr();
        inv.setValue( left );
        return inv;
      }
    }
    
    return this;
  }
}

/*
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.ast;

import java.util.ArrayList;
import java.util.List;

public class Function extends Node
{
  private String       name;
  private Type         type;
  private boolean      isStatic;
  private boolean      isInline;
  private List< Node > args;
  private List< Node > children;
  
  public Function()
  {
    super();
    
    name     = null;
    type     = null;
    isStatic = false;
    isInline = false;
    args     = new ArrayList< Node >();
    children = new ArrayList< Node >();
  }
  
  public String getName()
  {
    return name;
  }
  
  public void setName( String name )
  {
    this.name = name;
  }
  
  public Type getType()
  {
    return type;
  }
  
  public void setType( Type type )
  {
    this.type = type;
  }
  
  public boolean isStatic()
  {
    return isStatic;
  }
  
  public void setStatic( boolean isStatic )
  {
    this.isStatic = isStatic;
  }
  
  public boolean isInline()
  {
    return isInline;
  }
  
  public void setInline( boolean isInline )
  {
    this.isInline = isInline;
  }
  
  public void addArg( Node n )
  {
    args.add( n );
  }
  
  public void addStatement( Node n )
  {
    children.add( n );
  }
  
  public int getNumArgs()
  {
    return args.size();
  }
  
  public Node getArg( int index )
  {
    return args.get( index );
  }
  
  public Node optimize()
  {
    // Optimize statements.
    ArrayList< Node > pruned = new ArrayList< Node >();
    
    for ( int i = 0; i < children.size(); i++ )
    {
      Node child = children.get( i ).optimize();
      
      // Dead-code elimination.
      // If a statement is a constant it has no effect on the program. Remove it.
      if ( !( child instanceof ConstantExpr ) )
      {
        pruned.add( child );
        
        if ( child instanceof ReturnStmt )
        {
          break;
        }
      }
    }
    children = pruned;
    return this;
  }
  
  public String toDot()
  {
    StringBuilder sb = new StringBuilder();
    
    sb.append( getUid() ).append( " [ shape = record, label = \"{Function|" );
    
    sb.append( "name: " ).append( name );
    sb.append( '|' ).append( "type: " ).append( type );
    sb.append( '|' ).append( "isStatic: " ).append( isStatic );
    sb.append( '|' ).append( "isInline: " ).append( isInline );
    sb.append( "}\" ];\n" );
    
    for ( Node n: args )
    {
      sb.append( n.toDot() );
      sb.append( getUid() ).append( " -> " ).append( n.getUid() ).append( ";\n" );
    }
    
    for ( Node n: children )
    {
      sb.append( n.toDot() );
      sb.append( getUid() ).append( " -> " ).append( n.getUid() ).append( ";\n" );
    }
    
    return sb.toString();
  }
}

/*
Coco/R grammar for the SimpleC language.
Copyright (C) 2011 Andre Leiradella

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.leiradella.sv.parser.simplec;


import java.util.Stack;

import com.leiradella.sv.ast.*;
import com.leiradella.sv.parser.Scope;



public class Parser {
	public static final int _EOF = 0;
	public static final int _ident = 1;
	public static final int _oct_const = 2;
	public static final int _dec_const = 3;
	public static final int _hex_const = 4;
	public static final int _float_const = 5;
	public static final int maxT = 55;

	static final boolean T = true;
	static final boolean x = false;
	static final int minErrDist = 2;

	public Token t;    // last recognized token
	public Token la;   // lookahead token
	int errDist = minErrDist;
	
	public Scanner scanner;
	public Errors errors;

	private Stack< Scope > stack = new Stack< Scope >();
private Function       currentFunction = null;

private Scope pushScope()
{
  return stack.push( new Scope() );
}

private void popScope()
{
  stack.pop();
}

private Scope topScope()
{
  return stack.peek();
}

private void addVar( String name, Node node )
{
  if ( topScope().isDeclared( name ) )
  {
    Error( "Duplicate identifier: " + name );
  }
  else
  {
    topScope().addVar( name, node );
  }
}

private Node getVar( String name )
{
  int numScopes = stack.size();
  
  for ( int i = numScopes - 1; i >= 0; i-- )
  {
    Node node = stack.get( i ).getVar( name );
    
    if ( node != null )
    {
      return node;
    }
  }
  
  return null;
}

private void checkVar( String name )
{
  if ( getVar( name ) == null )
  {
    Error( "Unknown identifier: " + name );
  }
}

private void checkFunctionCall( String funcName, Node call )
{
  Node func = getVar( funcName );
  
  if ( !( func instanceof Function ) )
  {
    Error( "Not a function: " + funcName );
  }
  else
  {
    Function f = (Function)func;
    CallExpr c = (CallExpr)call;
    
    if ( f.getNumArgs() != c.getNumArgs() )
    {
      Error( "Wrong number of arguments: " + funcName );
    }
    
    for ( int i = 0; i < f.getNumArgs(); i++ )
    {
      Node farg = f.getArg( i );
      Node carg = c.getArg( i );
      
      checkImplicitCast( farg, carg );
    }
  }
}

private void checkImplicitCast( Node left, Node right )
{
  if ( left.getType() != right.getType() )
  {
    if ( left.getType() == Type.INT32 )
    {
      Warn( "Implicit conversion from float to int, possible loss of precision" );
    }
    else
    {
      Warn( "Implicit conversion from int to float, possible loss of precision" );
    }
  }
}

private void Warn( String msg )
{
  errors.Warning( t.line, t.col, msg );
}

private void Error( String msg )
{
  errors.Warning( t.line, t.col, msg );
  System.exit( 1 );
}

private boolean IsCastExpr()
{
  Token x = scanner.Peek();
  return la.val.equals( "(" ) && ( x.val.equals( "int" ) || x.val.equals( "float" ) );
}



	public Parser(Scanner scanner) {
		this.scanner = scanner;
		errors = new Errors();
	}

	void SynErr (int n) {
		if (errDist >= minErrDist) errors.SynErr(la.line, la.col, n);
		errDist = 0;
	}

	public void SemErr (String msg) {
		if (errDist >= minErrDist) errors.SemErr(t.line, t.col, msg);
		errDist = 0;
	}
	
	void Get () {
		for (;;) {
			t = la;
			la = scanner.Scan();
			if (la.kind <= maxT) {
				++errDist;
				break;
			}

			la = t;
		}
	}
	
	void Expect (int n) {
		if (la.kind==n) Get(); else { SynErr(n); }
	}
	
	boolean StartOf (int s) {
		return set[s][la.kind];
	}
	
	void ExpectWeak (int n, int follow) {
		if (la.kind == n) Get();
		else {
			SynErr(n);
			while (!StartOf(follow)) Get();
		}
	}
	
	boolean WeakSeparator (int n, int syFol, int repFol) {
		int kind = la.kind;
		if (kind == n) { Get(); return true; }
		else if (StartOf(repFol)) return false;
		else {
			SynErr(n);
			while (!(set[syFol][kind] || set[repFol][kind] || set[0][kind])) {
				Get();
				kind = la.kind;
			}
			return StartOf(syFol);
		}
	}
	
	Node  SimpleC() {
		Node  result;
		result  = unit();
		return result;
	}

	Node  unit() {
		Node  result;
		Unit unit = new Unit();
		result = unit;
		Node function;
		pushScope();
		
		function  = function();
		unit.addFunction( function ); 
		while (StartOf(1)) {
			function  = function();
			unit.addFunction( function ); 
		}
		return result;
	}

	Node  function() {
		Node  result;
		Function function = new Function();
		result = function;
		Type type;
		String name;
		Node stmt;
		
		if (la.kind == 6) {
			Get();
			function.setStatic( true ); 
		}
		if (la.kind == 7) {
			Get();
			function.setInline( true ); 
		}
		type  = type();
		name  = id();
		function.setName( name );
		function.setType( type );
		addVar( name, function );
		pushScope();
		
		Expect(8);
		if (la.kind == 13 || la.kind == 14) {
			stmt  = argDecl();
			function.addArg( stmt );
			addVar( ((ArgDecl)stmt).getName(), stmt );
			
			while (la.kind == 9) {
				Get();
				stmt  = argDecl();
				function.addArg( stmt );
				addVar( ((ArgDecl)stmt).getName(), stmt );
				
			}
		}
		Expect(10);
		currentFunction = function; 
		Expect(11);
		while (StartOf(2)) {
			stmt  = statement();
			function.addStatement( stmt ); 
		}
		Expect(12);
		currentFunction = null;
		popScope();
		
		return result;
	}

	Type  type() {
		Type  result;
		result = null; 
		if (la.kind == 13) {
			Get();
			result = Type.INT32;   
		} else if (la.kind == 14) {
			Get();
			result = Type.FLOAT32; 
		} else SynErr(56);
		return result;
	}

	String  id() {
		String  result;
		result = la.val; 
		Expect(1);
		return result;
	}

	Node  argDecl() {
		Node  result;
		ArgDecl arg = new ArgDecl();
		result = arg;
		Type type;
		String name;
		
		type  = type();
		name  = id();
		arg.setName( name );
		arg.setType( type );
		
		return result;
	}

	Node  statement() {
		Node  result;
		result = null; 
		switch (la.kind) {
		case 11: {
			result  = compoundStmt();
			break;
		}
		case 13: case 14: {
			result  = varDecls();
			break;
		}
		case 17: {
			result  = ifStmt();
			break;
		}
		case 19: {
			result  = forStmt();
			break;
		}
		case 20: {
			result  = doStmt();
			break;
		}
		case 21: {
			result  = whileStmt();
			break;
		}
		case 22: {
			result  = returnStmt();
			break;
		}
		case 1: case 2: case 3: case 4: case 5: case 8: case 48: case 49: case 53: case 54: {
			result  = expression();
			Expect(15);
			break;
		}
		default: SynErr(57); break;
		}
		return result;
	}

	Node  compoundStmt() {
		Node  result;
		CompoundStmt compound = new CompoundStmt();
		result = compound;
		Node stmt;
		
		Expect(11);
		pushScope(); 
		while (StartOf(2)) {
			stmt  = statement();
			compound.addStatement( stmt ); 
		}
		Expect(12);
		popScope(); 
		return result;
	}

	Node  varDecls() {
		Node  result;
		VarDecls vars = new VarDecls();
		result = vars;
		VarDecl var;
		Type type;
		String name;
		Node expr;
		
		type  = type();
		name  = id();
		var = new VarDecl();
		var.setName( name );
		var.setType( type );
		addVar( name, var );
		
		if (la.kind == 16) {
			Get();
			expr  = assignExpr();
			var.setValue( expr );
			checkImplicitCast( var, expr );
			
		}
		vars.addVarDecl( var ); 
		while (la.kind == 9) {
			Get();
			name  = id();
			var = new VarDecl();
			var.setName( name );
			var.setType( type );
			addVar( name, var );
			
			if (la.kind == 16) {
				Get();
				expr  = assignExpr();
				var.setValue( expr );
				checkImplicitCast( var, expr );
				
			}
			vars.addVarDecl( var ); 
		}
		Expect(15);
		return result;
	}

	Node  ifStmt() {
		Node  result;
		IfStmt ifstmt = new IfStmt();
		result = ifstmt;
		Node stmt;
		
		Expect(17);
		Expect(8);
		stmt  = expression();
		ifstmt.setCondition( stmt ); 
		Expect(10);
		stmt  = statement();
		ifstmt.setWhenTrue( stmt );  
		if (la.kind == 18) {
			Get();
			stmt  = statement();
			ifstmt.setWhenFalse( stmt ); 
		}
		return result;
	}

	Node  forStmt() {
		Node  result;
		ForStmt forstmt = new ForStmt();
		result = forstmt;
		Node stmt;
		
		Expect(19);
		Expect(8);
		if (StartOf(3)) {
			stmt  = expression();
			forstmt.setInit( stmt );      
		}
		Expect(15);
		if (StartOf(3)) {
			stmt  = expression();
			forstmt.setCondition( stmt ); 
		}
		Expect(15);
		if (StartOf(3)) {
			stmt  = expression();
			forstmt.setUpdate( stmt );    
		}
		Expect(10);
		stmt  = statement();
		forstmt.setBody( stmt );      
		return result;
	}

	Node  doStmt() {
		Node  result;
		DoStmt dostmt = new DoStmt();
		result = dostmt;
		Node stmt;
		
		Expect(20);
		stmt  = statement();
		dostmt.setBody( stmt );      
		Expect(21);
		Expect(8);
		stmt  = expression();
		dostmt.setCondition( stmt ); 
		Expect(10);
		Expect(15);
		return result;
	}

	Node  whileStmt() {
		Node  result;
		WhileStmt whilestmt = new WhileStmt();
		result = whilestmt;
		Node stmt;
		
		Expect(21);
		Expect(8);
		stmt  = expression();
		whilestmt.setCondition( stmt ); 
		Expect(10);
		stmt  = statement();
		whilestmt.setBody( stmt );      
		return result;
	}

	Node  returnStmt() {
		Node  result;
		ReturnStmt retstmt = new ReturnStmt();
		result = retstmt;
		Node expr;
		
		Expect(22);
		expr  = expression();
		retstmt.setValue( expr );
		checkImplicitCast( currentFunction, expr );
		
		Expect(15);
		return result;
	}

	Node  expression() {
		Node  result;
		Expression expr = new Expression();
		result = expr;
		Node assign;
		
		assign  = assignExpr();
		expr.addExpression( assign ); 
		while (la.kind == 9) {
			Get();
			assign  = assignExpr();
			expr.addExpression( assign ); 
		}
		return result;
	}

	Node  assignExpr() {
		Node  result;
		AssignExpr assign = new AssignExpr();
		Node right;
		BinaryOp binop = null;
		
		result  = ternaryExpr();
		if (StartOf(4)) {
			switch (la.kind) {
			case 16: {
				Get();
				assign.setLeft( result );
				binop = assign;
				
				break;
			}
			case 23: {
				Get();
				assign.setLeft( result );
				binop = new AddExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 24: {
				Get();
				assign.setLeft( result );
				binop = new SubExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 25: {
				Get();
				assign.setLeft( result );
				binop = new MulExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 26: {
				Get();
				assign.setLeft( result );
				binop = new DivExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 27: {
				Get();
				assign.setLeft( result );
				binop = new RemExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 28: {
				Get();
				assign.setLeft( result );
				binop = new BitwiseAndExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 29: {
				Get();
				assign.setLeft( result );
				binop = new BitwiseXorExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 30: {
				Get();
				assign.setLeft( result );
				binop = new BitwiseOrExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 31: {
				Get();
				assign.setLeft( result );
				binop = new ShiftLeftExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			case 32: {
				Get();
				assign.setLeft( result );
				binop = new ShiftRightExpr();
				binop.setLeft( result.dup() );
				assign.setRight( binop );
				
				break;
			}
			}
			if ( !( result instanceof IdExpr ) )
			 Error( "Invalid lvalue" );
			
			right  = assignExpr();
			checkImplicitCast( result, right );
			binop.setRight( right );
			result = assign;
			
		}
		return result;
	}

	Node  ternaryExpr() {
		Node  result;
		Node whentrue, whenfalse; 
		result  = orExpr();
		if (la.kind == 33) {
			Get();
			whentrue  = expression();
			Expect(34);
			whenfalse  = ternaryExpr();
			TernaryExpr ternary = new TernaryExpr();
			ternary.setCondition( result );
			ternary.setWhenTrue( whentrue );
			ternary.setWhenFalse( whenfalse );
			result = ternary;
			
		}
		return result;
	}

	Node  orExpr() {
		Node  result;
		Node right; 
		result  = andExpr();
		while (la.kind == 35) {
			Get();
			right  = andExpr();
			OrExpr or = new OrExpr();
			or.setLeft( result );
			or.setRight( right );
			result = or;
			
		}
		return result;
	}

	Node  andExpr() {
		Node  result;
		Node right; 
		result  = bitwiseOrExpr();
		while (la.kind == 36) {
			Get();
			right  = bitwiseOrExpr();
			AndExpr and = new AndExpr();
			and.setLeft( result );
			and.setRight( right );
			result = and;
			
		}
		return result;
	}

	Node  bitwiseOrExpr() {
		Node  result;
		Node right; 
		result  = bitwiseXorExpr();
		while (la.kind == 37) {
			Get();
			right  = bitwiseXorExpr();
			BitwiseOrExpr bor = new BitwiseOrExpr();
			bor.setLeft( result );
			bor.setRight( right );
			result = bor;
			
		}
		return result;
	}

	Node  bitwiseXorExpr() {
		Node  result;
		Node right; 
		result  = bitwiseAndExpr();
		while (la.kind == 38) {
			Get();
			right  = bitwiseAndExpr();
			BitwiseXorExpr bxor = new BitwiseXorExpr();
			bxor.setLeft( result );
			bxor.setRight( right );
			result = bxor;
			
		}
		return result;
	}

	Node  bitwiseAndExpr() {
		Node  result;
		Node right; 
		result  = equalityExpr();
		while (la.kind == 39) {
			Get();
			right  = equalityExpr();
			BitwiseAndExpr band = new BitwiseAndExpr();
			band.setLeft( result );
			band.setRight( right );
			result = band;
			
		}
		return result;
	}

	Node  equalityExpr() {
		Node  result;
		BinaryOp binop;
		Node right;
		
		result  = relationalExpr();
		while (la.kind == 40 || la.kind == 41) {
			if (la.kind == 40) {
				Get();
				binop = new EqualityExpr();   
			} else {
				Get();
				binop = new InequalityExpr(); 
			}
			right  = relationalExpr();
			binop.setLeft( result );
			binop.setRight( right );
			result = binop;
			
		}
		return result;
	}

	Node  relationalExpr() {
		Node  result;
		BinaryOp binop;
		Node right;
		
		result  = shiftExpr();
		while (StartOf(5)) {
			if (la.kind == 42) {
				Get();
				binop = new LessThanExpr();     
			} else if (la.kind == 43) {
				Get();
				binop = new LessEqualExpr();    
			} else if (la.kind == 44) {
				Get();
				binop = new GreaterThanExpr();  
			} else {
				Get();
				binop = new GreaterEqualExpr(); 
			}
			right  = shiftExpr();
			binop.setLeft( result );
			binop.setRight( right );
			result = binop;
			
		}
		return result;
	}

	Node  shiftExpr() {
		Node  result;
		BinaryOp binop;
		Node right;
		
		result  = addExpr();
		while (la.kind == 46 || la.kind == 47) {
			if (la.kind == 46) {
				Get();
				binop = new ShiftLeftExpr();  
			} else {
				Get();
				binop = new ShiftRightExpr(); 
			}
			right  = addExpr();
			binop.setLeft( result );
			binop.setRight( right );
			result = binop;
			
		}
		return result;
	}

	Node  addExpr() {
		Node  result;
		BinaryOp binop;
		Node right;
		
		result  = mulExpr();
		while (la.kind == 48 || la.kind == 49) {
			if (la.kind == 48) {
				Get();
				binop = new AddExpr(); 
			} else {
				Get();
				binop = new SubExpr(); 
			}
			right  = mulExpr();
			binop.setLeft( result );
			binop.setRight( right );
			result = binop;
			
		}
		return result;
	}

	Node  mulExpr() {
		Node  result;
		BinaryOp binop;
		Node right;
		
		result  = castExpr();
		while (la.kind == 50 || la.kind == 51 || la.kind == 52) {
			if (la.kind == 50) {
				Get();
				binop = new MulExpr(); 
			} else if (la.kind == 51) {
				Get();
				binop = new DivExpr(); 
			} else {
				Get();
				binop = new RemExpr(); 
			}
			right  = castExpr();
			binop.setLeft( result );
			binop.setRight( right );
			result = binop;
			
		}
		return result;
	}

	Node  castExpr() {
		Node  result;
		Type type;
		result = null;
		
		if (IsCastExpr() ) {
			Expect(8);
			type  = type();
			Expect(10);
			result  = castExpr();
			CastExpr cast = new CastExpr();
			cast.setType( type );
			cast.setValue( result );
			result = cast;
			
		} else if (StartOf(3)) {
			result  = unaryExpr();
		} else SynErr(58);
		return result;
	}

	Node  unaryExpr() {
		Node  result;
		UnaryOp unop;
		result = null;
		
		if (StartOf(6)) {
			if (la.kind == 48) {
				Get();
				unop = null;             
			} else if (la.kind == 49) {
				Get();
				unop = new NegateExpr(); 
			} else if (la.kind == 53) {
				Get();
				unop = new InvertExpr(); 
			} else {
				Get();
				unop = new NotExpr();    
			}
			result  = castExpr();
			if ( unop != null ) {
			 if ( unop instanceof InvertExpr && result.getType() != Type.INT32 )
			   Error( "Wrong type argument to bit-complement" );
			 unop.setValue( result );
			 result = unop;
			}
			
		} else if (StartOf(7)) {
			result  = primaryExpr();
		} else SynErr(59);
		return result;
	}

	Node  primaryExpr() {
		Node  result;
		String name;
		Node arg;
		result = null;
		boolean isFunction = false;
		
		switch (la.kind) {
		case 1: {
			name  = id();
			checkVar( name );
			IdExpr id = new IdExpr();
			result = id;
			Node var = getVar( name );
			if ( var instanceof ArgDecl )
			  id.setVar( (ArgDecl)var );
			
			if (la.kind == 8) {
				Get();
				if ( !( var instanceof Function ) )
				 Error( "Not a function: " + name );
				isFunction = true;
				CallExpr call = new CallExpr();
				call.setFunction( (Function)var );
				result = call;
				
				if (StartOf(3)) {
					arg  = assignExpr();
					call.addArg( arg ); 
					while (la.kind == 9) {
						Get();
						arg  = assignExpr();
						call.addArg( arg ); 
					}
				}
				Expect(10);
				checkFunctionCall( name, call ); 
			}
			if ( !isFunction && var instanceof Function )
			 Error( "Missing arguments to " + name );
			
			break;
		}
		case 2: {
			result  = octalConst();
			break;
		}
		case 3: {
			result  = decimalConst();
			break;
		}
		case 4: {
			result  = hexadecimalConst();
			break;
		}
		case 5: {
			result  = floatConst();
			break;
		}
		case 8: {
			Get();
			result  = expression();
			Expect(10);
			break;
		}
		default: SynErr(60); break;
		}
		return result;
	}

	Node  octalConst() {
		Node  result;
		ConstantExpr constant = new ConstantExpr();
		constant.setValue( Long.parseLong( la.val, 8 ) );
		constant.setType( Type.INT32 );
		result = constant;
		
		Expect(2);
		return result;
	}

	Node  decimalConst() {
		Node  result;
		ConstantExpr constant = new ConstantExpr();
		constant.setValue( Long.parseLong( la.val, 10 ) );
		constant.setType( Type.INT32 );
		result = constant;
		
		Expect(3);
		return result;
	}

	Node  hexadecimalConst() {
		Node  result;
		ConstantExpr constant = new ConstantExpr();
		constant.setValue( Long.parseLong( la.val.substring( 2 ), 16 ) );
		constant.setType( Type.INT32 );
		result = constant;
		
		Expect(4);
		return result;
	}

	Node  floatConst() {
		Node  result;
		ConstantExpr constant = new ConstantExpr();
		constant.setValue( la.val );
		constant.setType( Type.FLOAT32 );
		result = constant;
		
		Expect(5);
		return result;
	}



	public Object Parse() {
		la = new Token();
		la.val = "";		
		Get();
    Object result =
		SimpleC();
		Expect(0);

    return result;
	}

	private static final boolean[][] set = {
		{T,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x},
		{x,x,x,x, x,x,T,T, x,x,x,x, x,T,T,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x},
		{x,T,T,T, T,T,x,x, T,x,x,T, x,T,T,x, x,T,x,T, T,T,T,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, T,T,x,x, x,T,T,x, x},
		{x,T,T,T, T,T,x,x, T,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, T,T,x,x, x,T,T,x, x},
		{x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, T,x,x,x, x,x,x,T, T,T,T,T, T,T,T,T, T,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x},
		{x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,T,T, T,T,x,x, x,x,x,x, x,x,x,x, x},
		{x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, T,T,x,x, x,T,T,x, x},
		{x,T,T,T, T,T,x,x, T,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x,x,x,x, x}

	};
} // end Parser


class Errors {
	public int count = 0;                                    // number of errors detected
	public java.io.PrintStream errorStream = System.err;     // error messages go to this stream
	public String errMsgFormat = "-- line {0} col {1}: {2}"; // 0=line, 1=column, 2=text
	
	protected void printMsg(int line, int column, String msg) {
		StringBuffer b = new StringBuffer(errMsgFormat);
		int pos = b.indexOf("{0}");
		if (pos >= 0) { b.delete(pos, pos+3); b.insert(pos, line); }
		pos = b.indexOf("{1}");
		if (pos >= 0) { b.delete(pos, pos+3); b.insert(pos, column); }
		pos = b.indexOf("{2}");
		if (pos >= 0) b.replace(pos, pos+3, msg);
		errorStream.println(b.toString());
	}
	
	public void SynErr (int line, int col, int n) {
		String s;
		switch (n) {
			case 0: s = "EOF expected"; break;
			case 1: s = "ident expected"; break;
			case 2: s = "oct_const expected"; break;
			case 3: s = "dec_const expected"; break;
			case 4: s = "hex_const expected"; break;
			case 5: s = "float_const expected"; break;
			case 6: s = "\"static\" expected"; break;
			case 7: s = "\"inline\" expected"; break;
			case 8: s = "\"(\" expected"; break;
			case 9: s = "\",\" expected"; break;
			case 10: s = "\")\" expected"; break;
			case 11: s = "\"{\" expected"; break;
			case 12: s = "\"}\" expected"; break;
			case 13: s = "\"int\" expected"; break;
			case 14: s = "\"float\" expected"; break;
			case 15: s = "\";\" expected"; break;
			case 16: s = "\"=\" expected"; break;
			case 17: s = "\"if\" expected"; break;
			case 18: s = "\"else\" expected"; break;
			case 19: s = "\"for\" expected"; break;
			case 20: s = "\"do\" expected"; break;
			case 21: s = "\"while\" expected"; break;
			case 22: s = "\"return\" expected"; break;
			case 23: s = "\"+=\" expected"; break;
			case 24: s = "\"-=\" expected"; break;
			case 25: s = "\"*=\" expected"; break;
			case 26: s = "\"/=\" expected"; break;
			case 27: s = "\"%=\" expected"; break;
			case 28: s = "\"&=\" expected"; break;
			case 29: s = "\"^=\" expected"; break;
			case 30: s = "\"|=\" expected"; break;
			case 31: s = "\"<<=\" expected"; break;
			case 32: s = "\">>=\" expected"; break;
			case 33: s = "\"?\" expected"; break;
			case 34: s = "\":\" expected"; break;
			case 35: s = "\"||\" expected"; break;
			case 36: s = "\"&&\" expected"; break;
			case 37: s = "\"|\" expected"; break;
			case 38: s = "\"^\" expected"; break;
			case 39: s = "\"&\" expected"; break;
			case 40: s = "\"==\" expected"; break;
			case 41: s = "\"!=\" expected"; break;
			case 42: s = "\"<\" expected"; break;
			case 43: s = "\"<=\" expected"; break;
			case 44: s = "\">\" expected"; break;
			case 45: s = "\">=\" expected"; break;
			case 46: s = "\"<<\" expected"; break;
			case 47: s = "\">>\" expected"; break;
			case 48: s = "\"+\" expected"; break;
			case 49: s = "\"-\" expected"; break;
			case 50: s = "\"*\" expected"; break;
			case 51: s = "\"/\" expected"; break;
			case 52: s = "\"%\" expected"; break;
			case 53: s = "\"~\" expected"; break;
			case 54: s = "\"!\" expected"; break;
			case 55: s = "??? expected"; break;
			case 56: s = "invalid type"; break;
			case 57: s = "invalid statement"; break;
			case 58: s = "invalid castExpr"; break;
			case 59: s = "invalid unaryExpr"; break;
			case 60: s = "invalid primaryExpr"; break;
			default: s = "error " + n; break;
		}
		printMsg(line, col, s);
		count++;
	}

	public void SemErr (int line, int col, String s) {	
		printMsg(line, col, s);
		count++;
	}
	
	public void SemErr (String s) {
		errorStream.println(s);
		count++;
	}
	
	public void Warning (int line, int col, String s) {	
		printMsg(line, col, s);
	}
	
	public void Warning (String s) {
		errorStream.println(s);
	}
} // Errors


class FatalError extends RuntimeException {
	public static final long serialVersionUID = 1L;
	public FatalError(String s) { super(s); }
}

#!/bin/sh

java -jar cocor/Coco.jar cocor/SimpleC.atg -o com/leiradella/sv/parser/simplec

find . -type f -name '*.class' -exec rm -f {} \;
javac -cp . Main.java
